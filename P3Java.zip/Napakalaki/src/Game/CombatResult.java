/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Game;

/**
 * Posibles resultados de combate
 * @author Francisco David Charte Luque
 * @author Ignacio Cordón Castillo
 */
public enum CombatResult {
    WINANDWINGAME,
    WIN,
    LOSE,
    LOSEANDESCAPE,
    LOSEANDDIE
}
