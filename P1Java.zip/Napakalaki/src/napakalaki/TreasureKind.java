/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package napakalaki;

/**
 * Enumerado de tipos de tesoro
 * @author Francisco David Charte Luque
 * @author Ignacio Cordón Castillo
 */
public enum TreasureKind {
    ARMOR,
    ONEHAND,
    BOTHHANDS,
    HELMET,
    SHOE,
    NECKLACE;
}
